# SN SHRABON Dev — TikTok Profile Checker

A Vite + React + Vercel serverless app for checking publicly available TikTok profile statistics by username.

## Features
- Username / @username input
- Followers, following, likes, videos
- Public/private and verified status
- Avatar, nickname and bio/signature
- Scanned public-video share total
- Robust JSON/error handling (no `Unexpected end of JSON input`)
- Timeout and upstream failure messages
- 60-second server-side cache
- Same-origin `/api/profile` endpoint

## Important limitation
TikTok does not provide a reliable profile-level lifetime share-count field through this provider. The displayed share number is the sum of share counts returned for the public videos scanned by the provider, and is explicitly not a lifetime total.

## Deploy
1. Upload the project to Vercel.
2. Run `npm install` and `npm run build` locally if desired.
3. Deploy with the Vercel default settings. `/api/profile.js` is automatically exposed as `/api/profile`.

No TikTok login or password is required.
