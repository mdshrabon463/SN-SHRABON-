const TIKWM_ENDPOINT = 'https://www.tikwm.com/api';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36';
const CACHE = new Map();
const CACHE_TTL = 60_000;

class ProfileError extends Error {
  constructor(code, message, status = 502) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');
  res.setHeader('Cache-Control', 'no-store');
}

function cleanUsername(value) {
  const raw = String(value ?? '').trim().replace(/^@+/, '');
  return raw.replace(/[^A-Za-z0-9._-]/g, '').slice(0, 64);
}

function number(...values) {
  for (const value of values) {
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return 0;
}

async function requestTikwm(path, params) {
  const qs = new URLSearchParams(params);
  const url = `${TIKWM_ENDPOINT}/${path}?${qs.toString()}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 18_000);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': UA,
        Accept: 'application/json, text/plain, */*',
        Referer: 'https://www.tikwm.com/',
      },
    });
    const raw = await response.text();
    let data = null;
    try { data = raw.trim() ? JSON.parse(raw) : null; } catch { data = null; }
    return { response, data, raw };
  } catch (error) {
    if (error?.name === 'AbortError') throw new ProfileError('UPSTREAM_TIMEOUT', 'TikTok service timed out. Please try again.', 504);
    throw new ProfileError('UPSTREAM_UNREACHABLE', 'TikTok profile service is temporarily unreachable.', 502);
  } finally {
    clearTimeout(timer);
  }
}

async function getTikwm(path, params) {
  let result = await requestTikwm(path, params);
  // TikWM supports GET for these endpoints. A second request is intentionally
  // avoided for normal API errors so we do not amplify rate limits.
  if (!result.response.ok) {
    throw new ProfileError('UPSTREAM_HTTP', `TikTok profile service returned HTTP ${result.response.status}.`, 502);
  }
  if (!result.data) throw new ProfileError('UPSTREAM_INVALID', 'TikTok profile service returned an invalid response.', 502);
  return result.data;
}

function apiSucceeded(data) {
  return data && Number(data.code) === 0 && data.data;
}

async function fetchUser(username) {
  const data = await getTikwm('user/info', { unique_id: username });
  if (!apiSucceeded(data)) {
    const msg = String(data?.msg || '').toLowerCase();
    if (/not found|not exist|invalid|user/i.test(msg)) {
      throw new ProfileError('USER_NOT_FOUND', 'এই username-এর TikTok account পাওয়া যায়নি বা public নয়।', 404);
    }
    throw new ProfileError('PROFILE_UNAVAILABLE', data?.msg || 'TikTok profile information is unavailable.', 502);
  }
  return data.data;
}

async function fetchPosts(username, count = 35, cursor = '0') {
  const data = await getTikwm('user/posts', { unique_id: username, count: String(count), cursor: String(cursor) });
  if (!apiSucceeded(data)) throw new ProfileError('POSTS_UNAVAILABLE', data?.msg || 'TikTok video list is unavailable.', 502);
  return data.data;
}

function mapProfile(username, info, posts) {
  const u = info?.user || {};
  const s = info?.stats || {};
  const videos = Array.isArray(posts?.videos) ? posts.videos : [];
  const author = videos[0]?.author || {};

  let shares = 0;
  for (const video of videos) shares += number(video.share_count, video.shareCount, video.stats?.shareCount, video.stats?.share_count);

  const videoCount = number(
    s.videoCount, s.video_count, u.videoCount, u.video_count,
    posts?.total,
    posts?.totalCount
  );

  return {
    username: String(u.uniqueId || u.unique_id || author.uniqueId || author.unique_id || username),
    nickname: String(u.nickname || author.nickname || username),
    avatar: u.avatarLarger || u.avatarMedium || u.avatarThumb || author.avatar || null,
    verified: Boolean(u.verified),
    privateAccount: Boolean(u.privateAccount ?? u.private_account),
    signature: String(u.signature || ''),
    followers: number(s.followerCount, s.follower_count, u.followerCount, u.follower_count),
    following: number(s.followingCount, s.following_count, u.followingCount, u.following_count),
    likes: number(s.heartCount, s.heart_count, s.heart, u.heartCount, u.total_favorited),
    videos: videoCount,
    shares,
    sharesScannedVideos: videos.length,
    sharesExact: false,
    checkedAt: new Date().toISOString(),
  };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET' && req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'METHOD_NOT_ALLOWED', message: 'GET or POST required.' });
  }

  let input = req.method === 'GET' ? req.query?.username : req.body?.username;
  if (typeof req.body === 'string') {
    try { input = JSON.parse(req.body)?.username; } catch {
      return res.status(400).json({ success: false, error: 'INVALID_JSON', message: 'Invalid request body.' });
    }
  }

  const username = cleanUsername(input);
  if (!username) return res.status(400).json({ success: false, error: 'MISSING_USERNAME', message: 'একটি TikTok username দিন।' });
  if (username.length < 2) return res.status(400).json({ success: false, error: 'INVALID_USERNAME', message: 'সঠিক TikTok username দিন।' });

  const key = username.toLowerCase();
  const cached = CACHE.get(key);
  if (cached && Date.now() - cached.time < CACHE_TTL) return res.status(200).json({ success: true, profile: cached.profile, cached: true });

  try {
    let info = null;
    let posts = null;
    try {
      info = await fetchUser(username);
    } catch (error) {
      // If profile endpoint is unavailable, posts can still provide a public
      // author's identity and a scanned share count. Do not hide the real error
      // if posts also fail.
      if (!(error instanceof ProfileError)) throw error;
      if (error.code === 'USER_NOT_FOUND') throw error;
      try { posts = await fetchPosts(username); } catch { throw error; }
    }

    if (!posts) {
      try { posts = await fetchPosts(username); } catch { posts = { videos: [], total: 0 }; }
    }

    const profile = mapProfile(username, info, posts);
    CACHE.set(key, { time: Date.now(), profile });
    return res.status(200).json({ success: true, profile, cached: false, source: 'TikWM' });
  } catch (error) {
    const e = error instanceof ProfileError ? error : new ProfileError('PROFILE_ERROR', 'এই মুহূর্তে profile check করা যাচ্ছে না।', 502);
    return res.status(e.status).json({ success: false, error: e.code, message: e.message });
  }
}
