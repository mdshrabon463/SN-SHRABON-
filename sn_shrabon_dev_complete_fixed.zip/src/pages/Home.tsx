import { FormEvent, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Loader2, UserRound, Heart, Video, Share2, Users, UserCheck, BadgeCheck, AlertCircle, RotateCcw } from 'lucide-react';
import { checkProfile, formatCount, type TikTokProfile } from '../lib/profileApi';

type Phase = 'idle' | 'loading' | 'result' | 'error';

const stats = (p: TikTokProfile) => [
  { label: 'মোট লাইক', value: p.likes, icon: Heart },
  { label: 'মোট ভিডিও', value: p.videos, icon: Video },
  { label: 'শেয়ার', value: p.shares, icon: Share2 },
  { label: 'ফলোয়ার', value: p.followers, icon: Users },
  { label: 'ফলোয়িং', value: p.following, icon: UserCheck },
];

export default function Home() {
  const [username, setUsername] = useState('');
  const [phase, setPhase] = useState<Phase>('idle');
  const [profile, setProfile] = useState<TikTokProfile | null>(null);
  const [error, setError] = useState('');

  async function handleCheck(e?: FormEvent) {
    e?.preventDefault();
    const value = username.trim().replace(/^@+/, '');
    if (!value) { setError('একটি TikTok username দিন।'); setPhase('error'); return; }
    setPhase('loading'); setError(''); setProfile(null);
    try { setProfile(await checkProfile(value)); setPhase('result'); }
    catch (err) { setError(err instanceof Error ? err.message : 'চেক করা যায়নি। আবার চেষ্টা করুন।'); setPhase('error'); }
  }

  return (
    <main className="min-h-screen overflow-x-hidden bg-[#06060f] text-white">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute -top-40 left-1/2 h-[520px] w-[900px] -translate-x-1/2 rounded-full bg-[#fe2c55]/15 blur-[150px]" />
        <div className="absolute top-1/3 -left-40 h-[420px] w-[420px] rounded-full bg-[#25f4ee]/10 blur-[130px]" />
        <div className="absolute bottom-0 -right-40 h-[420px] w-[420px] rounded-full bg-violet-600/10 blur-[130px]" />
      </div>

      <section className="relative z-10 mx-auto flex min-h-screen max-w-5xl flex-col px-5 py-10 sm:py-16">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-[#25f4ee] via-[#555568] to-[#fe2c55] p-[2px]">
              <div className="flex h-full w-full items-center justify-center rounded-2xl bg-[#0b0b15]"><UserRound className="h-5 w-5 text-[#25f4ee]" /></div>
            </div>
            <div><p className="text-lg font-extrabold">SN <span className="text-[#fe2c55]">SHRABON</span> Dev</p><p className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">Profile Checker</p></div>
          </div>
          <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1.5 text-xs font-semibold text-emerald-300">● Live checker</span>
        </header>

        <div className="mx-auto w-full max-w-3xl flex-1 pt-16 text-center sm:pt-24">
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
            <p className="mb-4 text-xs font-bold uppercase tracking-[0.28em] text-[#25f4ee]">TikTok account analytics</p>
            <h1 className="text-4xl font-black tracking-tight sm:text-6xl">Username দিন,<br /><span className="bg-gradient-to-r from-[#25f4ee] via-white to-[#fe2c55] bg-clip-text text-transparent">অটোমেটিক কাউন্ট দেখুন</span></h1>
            <p className="mx-auto mt-5 max-w-2xl text-sm leading-6 text-zinc-400 sm:text-base">@username লিখে Check চাপুন। পাবলিক TikTok প্রোফাইলের লাইক, ভিডিও, ফলোয়ার ও ফলোয়িংসহ উপলব্ধ পরিসংখ্যান এক জায়গায় দেখাবে।</p>
          </motion.div>

          <form onSubmit={handleCheck} className="mx-auto mt-9 flex max-w-2xl flex-col gap-3 sm:flex-row">
            <div className="relative flex-1"><span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500">@</span><input value={username} onChange={e => setUsername(e.target.value)} placeholder="username লিখুন" className="h-14 w-full rounded-2xl border border-white/10 bg-white/[0.06] pl-9 pr-4 outline-none transition placeholder:text-zinc-600 focus:border-[#25f4ee]/50 focus:bg-white/[0.08]" /></div>
            <button disabled={phase === 'loading'} className="h-14 rounded-2xl bg-gradient-to-r from-[#25f4ee] to-[#fe2c55] px-7 font-extrabold text-black transition hover:scale-[1.01] disabled:cursor-wait disabled:opacity-60">{phase === 'loading' ? <span className="flex items-center justify-center gap-2"><Loader2 className="h-5 w-5 animate-spin" /> Checking…</span> : <span className="flex items-center justify-center gap-2"><Search className="h-5 w-5" /> Check Account</span>}</button>
          </form>

          {phase === 'error' && <div className="mx-auto mt-5 flex max-w-2xl items-center justify-between gap-3 rounded-2xl border border-red-400/20 bg-red-400/10 p-4 text-left text-sm text-red-200"><span className="flex items-center gap-2"><AlertCircle className="h-5 w-5 shrink-0" />{error}</span><button onClick={() => handleCheck()} className="shrink-0 rounded-lg p-2 hover:bg-white/10"><RotateCcw className="h-4 w-4" /></button></div>}

          {profile && phase === 'result' && (
            <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="mt-10 text-left">
              <div className="rounded-[28px] border border-white/10 bg-white/[0.055] p-5 shadow-2xl backdrop-blur-xl sm:p-7">
                <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
                  <div className="h-20 w-20 overflow-hidden rounded-full border-2 border-[#25f4ee]/40 bg-zinc-900">{profile.avatar ? <img src={profile.avatar} alt="TikTok avatar" className="h-full w-full object-cover" /> : <UserRound className="m-6 h-8 w-8 text-zinc-500" />}</div>
                  <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h2 className="text-2xl font-black truncate">{profile.nickname}</h2>{profile.verified && <BadgeCheck className="h-5 w-5 text-[#25f4ee]" />}</div><p className="mt-1 text-sm text-[#25f4ee]">@{profile.username}</p>{profile.signature && <p className="mt-2 line-clamp-2 text-sm text-zinc-400">{profile.signature}</p>}</div>
                  <span className="rounded-full border border-white/10 bg-black/20 px-3 py-1.5 text-xs text-zinc-400">{profile.privateAccount ? 'Private account' : 'Public account'}</span>
                </div>
                <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-5">{stats(profile).map(({ label, value, icon: Icon }) => <div key={label} className="rounded-2xl border border-white/7 bg-black/20 p-4"><Icon className="h-4 w-4 text-[#fe2c55]" /><p className="mt-3 text-xl font-black">{formatCount(value)}</p><p className="mt-1 text-[11px] text-zinc-500">{label}</p></div>)}</div>
                <div className="mt-5 rounded-2xl border border-yellow-400/10 bg-yellow-400/[0.04] p-3 text-xs leading-5 text-zinc-500">শেয়ার কাউন্ট TikTok-এর profile-level lifetime total হিসেবে সরাসরি দেওয়া হয় না। তাই এখানে public ভিডিও থেকে যতগুলো share count পাওয়া গেছে, সেগুলোর যোগফল দেখানো হচ্ছে — এটিকে lifetime total হিসেবে ধরা যাবে না।</div>
              </div>
            </motion.div>
          )}

          <p className="mt-7 text-xs text-zinc-600">শুধু পাবলিকভাবে পাওয়া তথ্য • কোনো TikTok password বা login প্রয়োজন নেই</p>
        </div>
      </section>
    </main>
  );
}
