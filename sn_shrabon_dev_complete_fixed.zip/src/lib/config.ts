/**
 * BotCoderTikTok — backend endpoint configuration.
 *
 * DOWNLOAD_API_URL is automatically wired to the real server-side
 * downloader service that ships with this project (same origin, no
 * third-party API key or manual setup required):
 *
 *   POST /api/download  { url: "https://www.tiktok.com/@user/video/123…" }
 *   GET  /api/download?url=…   (same behaviour)
 *   GET  /api/download         (health check -> { status: "online" })
 *
 * Actual file bytes are served through:
 *   GET /api/stream?v=<videoId>&q=hd|sd|wm|audio&mode=download|preview
 *
 * All TikTok / upstream-provider logic and secrets stay server-side in
 * api/tiktok-lib.js, api/download.js and api/stream.js.
 */
export const DOWNLOAD_API_URL = '/api/download';
export const STREAM_API_URL = '/api/stream';
export const HISTORY_API_URL = '/api/history';
