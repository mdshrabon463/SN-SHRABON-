export interface TikTokProfile {
  username: string;
  nickname: string;
  avatar: string | null;
  verified: boolean;
  privateAccount: boolean;
  signature: string;
  followers: number;
  following: number;
  likes: number;
  videos: number;
  shares: number;
  sharesScannedVideos: number;
  sharesExact: boolean;
  checkedAt: string;
}

export async function checkProfile(username: string): Promise<TikTokProfile> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 25_000);
  try {
    const res = await fetch('/api/profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ username }),
      signal: controller.signal,
    });

    const raw = await res.text();
    let data: any = null;
    if (raw.trim()) {
      try { data = JSON.parse(raw); } catch {
        throw new Error(`Server valid JSON দেয়নি (HTTP ${res.status})। Vercel/API deployment ঠিক আছে কি না দেখুন।`);
      }
    }

    if (!res.ok || !data?.success || !data.profile) {
      const code = data?.error;
      if (code === 'USER_NOT_FOUND') throw new Error('এই TikTok username পাওয়া যায়নি বা account public নয়।');
      if (code === 'UPSTREAM_TIMEOUT') throw new Error('TikTok service উত্তর দিতে দেরি করছে। কয়েক সেকেন্ড পর আবার চেষ্টা করুন।');
      if (code === 'UPSTREAM_UNREACHABLE') throw new Error('TikTok profile service এখন পাওয়া যাচ্ছে না। পরে আবার চেষ্টা করুন।');
      throw new Error(data?.message || data?.error || `Profile service error (HTTP ${res.status})`);
    }
    return data.profile as TikTokProfile;
  } catch (error: any) {
    if (error?.name === 'AbortError') throw new Error('Request timeout হয়েছে। আবার চেষ্টা করুন।');
    throw error;
  } finally {
    window.clearTimeout(timer);
  }
}

export function formatCount(n: number): string {
  if (!Number.isFinite(n)) return '0';
  if (n < 1000) return String(Math.round(n));
  if (n < 1_000_000) return `${(n / 1000).toFixed(1).replace(/\.0$/, '')}K`;
  if (n < 1_000_000_000) return `${(n / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`;
  return `${(n / 1_000_000_000).toFixed(1).replace(/\.0$/, '')}B`;
}
