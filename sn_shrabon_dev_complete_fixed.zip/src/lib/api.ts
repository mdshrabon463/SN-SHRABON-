import { DOWNLOAD_API_URL, HISTORY_API_URL } from './config';

export interface QualityOption {
  key: string;
  quality: string;
  tier: string;
  width: number | null;
  height: number | null;
  size: number | null;
  noWatermark: boolean;
  available: boolean;
  reason: string | null;
  downloadUrl: string | null;
  previewUrl: string | null;
}

export interface VideoInfo {
  id: string;
  title: string;
  author: { uniqueId: string; nickname: string; avatar: string | null };
  cover: string | null;
  duration: number;
  stats: { plays: number; likes: number; comments: number; shares: number };
}

export interface ResolveResponse {
  success: boolean;
  cached?: boolean;
  video?: VideoInfo;
  qualities?: QualityOption[];
  best?: string;
  error?: string;
  message?: string;
}

export interface ServiceStatus {
  state: 'checking' | 'online' | 'offline';
  detail?: string;
}

/** DOWNLOAD_API_URL is pre-configured (src/lib/config.ts) → same-origin real backend. */
export async function checkService(): Promise<ServiceStatus> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 12000);
    const res = await fetch(DOWNLOAD_API_URL, { signal: ctrl.signal });
    clearTimeout(t);
    if (!res.ok) return { state: 'offline', detail: `HTTP ${res.status}` };
    const j = await res.json();
    if (j && j.status === 'online') return { state: 'online' };
    return { state: 'offline', detail: 'Unexpected response' };
  } catch (e) {
    return { state: 'offline', detail: e instanceof Error ? e.message : 'Unreachable' };
  }
}

export async function resolveTikTok(url: string): Promise<ResolveResponse> {
  const res = await fetch(DOWNLOAD_API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url }),
  });
  const data = (await res.json()) as ResolveResponse;
  if (!res.ok || !data.success) {
    throw new DownloadError(data.error || 'SERVICE_ERROR', data.message || 'Something went wrong.');
  }
  return data;
}

export class DownloadError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

export function friendlyError(code: string, message: string): { title: string; hint: string } {
  switch (code) {
    case 'MISSING_URL':
      return { title: 'No link provided', hint: 'Paste a TikTok video link into the box above and try again.' };
    case 'INVALID_URL':
      return { title: 'Invalid TikTok link', hint: 'Copy the full link from the TikTok app or website (it must contain tiktok.com and /video/).' };
    case 'VIDEO_UNAVAILABLE':
      return { title: 'Video unavailable', hint: 'This video is likely private, deleted, or region-restricted. Photo slideshows without a video file cannot be downloaded either.' };
    case 'RATE_LIMITED':
      return { title: 'Too many requests', hint: 'Please wait about 10 seconds and try again.' };
    case 'UPSTREAM_ERROR':
      return { title: 'Video service busy', hint: 'TikTok did not respond correctly. Wait a moment and retry — your link is fine.' };
    default:
      return { title: 'Something went wrong', hint: message || 'Please try again in a moment.' };
  }
}

export async function fetchHistory() {
  try {
    const res = await fetch(HISTORY_API_URL);
    if (!res.ok) return [];
    const j = await res.json();
    return j.history || [];
  } catch {
    return [];
  }
}

export function formatBytes(n: number | null | undefined): string {
  if (n == null || !Number.isFinite(n) || n <= 0) return '—';
  if (n < 1024) return `${n} B`;
  const units = ['B', 'KB', 'MB', 'GB'];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v >= 10 ? 1 : 2)} ${units[i]}`;
}

export function formatCount(n: number | null | undefined): string {
  if (n == null || !Number.isFinite(n)) return '0';
  if (n < 1000) return String(n);
  if (n < 1_000_000) return `${(n / 1000).toFixed(1).replace(/\.0$/, '')}K`;
  if (n < 1_000_000_000) return `${(n / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`;
  return `${(n / 1_000_000_000).toFixed(1).replace(/\.0$/, '')}B`;
}

export function formatDuration(s: number | null | undefined): string {
  if (!s || s <= 0) return '0:00';
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${String(r).padStart(2, '0')}`;
}
